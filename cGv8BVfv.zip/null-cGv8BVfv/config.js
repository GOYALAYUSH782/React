const tokenUrl = "https://us1.pusherplatform.io/services/chatkit_token_provider/v1/af799227-05d3-4a5b-ae27-8e378f5683b1/token";
const instanceLocator = "v1:us1:af799227-05d3-4a5b-ae27-8e378f5683b1";

export { tokenUrl, instanceLocator }